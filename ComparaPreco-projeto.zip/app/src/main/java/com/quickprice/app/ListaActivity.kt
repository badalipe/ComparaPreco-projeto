package com.quickprice.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import org.jsoup.Jsoup
import java.util.concurrent.Executors
import java.util.Locale

class ListaActivity : AppCompatActivity() {

    private lateinit var store: ListaComprasStore
    private lateinit var container: LinearLayout
    private val imgPool = Executors.newSingleThreadExecutor()
    private val cacheImg = HashMap<String, String?>()

    /** Carrega a foto do produto: usa a URL salva, senão busca no BeepScan em fila (sem disparar tudo junto). */
    private fun carregarImagem(img: ImageView, barcode: String, urlSalva: String) {
        if (urlSalva.isNotEmpty()) {
            Glide.with(this).load(urlSalva).error(R.drawable.ic_placeholder_box).into(img)
            return
        }
        img.setImageResource(R.drawable.ic_placeholder_box)
        if (barcode.isEmpty()) return
        cacheImg[barcode]?.let {
            if (it.isNotEmpty()) Glide.with(this).load(it).error(R.drawable.ic_placeholder_box).into(img)
            return
        }
        imgPool.execute {
            var url = ""
            repeat(3) { tentativa ->
                if (url.isEmpty()) {
                    if (tentativa > 0) try { Thread.sleep(1500) } catch (_: Exception) {}
                    url = try {
                        val doc = Jsoup.connect("https://www.beepscan.com/barcode/$barcode")
                            .userAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                            .timeout(10000)
                            .get()
                        doc.selectFirst("meta[property=og:image]")?.attr("abs:content")
                            ?.takeIf { it.startsWith("http") } ?: ""
                    } catch (e: Exception) { "" }
                }
            }
            if (url.isNotEmpty()) {
                cacheImg[barcode] = url
                runOnUiThread {
                    Glide.with(this@ListaActivity).load(url)
                        .error(R.drawable.ic_placeholder_box).into(img)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ListaComprasStore(this)

        val scroll = ScrollView(this)
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(container)
        setContentView(scroll)
        montar()
    }

    private fun montar() {
        container.removeAllViews()
        val itens = store.todos()

        container.addView(TextView(this).apply {
            text = "🛒 LISTA DE COMPRAS"
            setTextColor(0xFF8FA3FF.toInt())
            textSize = 13f
        })

        if (itens.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "\nNenhum item salvo ainda.\n\nEscaneie um produto e toque em\n\"Salvar na lista de compras\"."
                setTextColor(Color.WHITE)
                textSize = 16f
            })
            return
        }

        // Itens
        itens.forEachIndexed { index, item ->
            container.addView(linha(item, index))
        }

        // Totais por mercado
        container.addView(divisor(), ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        val porMercado = LinkedHashMap<String, Double>()
        itens.forEach { porMercado[itemLabel(it)] = (porMercado[itemLabel(it)] ?: 0.0) + it.precoValor }

        porMercado.forEach { (mercado, total) ->
            container.addView(TextView(this).apply {
                text = "Gastar no $mercado: ${moeda(total)}"
                setTextColor(Color.WHITE)
                textSize = 16f
            })
        }

        container.addView(TextView(this).apply {
            text = "\n💰 ECONOMIA TOTAL: ${moeda(store.economiaTotal())}"
            setTextColor(0xFF4ADE80.toInt())
            textSize = 19f
        })

        val btnLimpar = Button(this).apply {
            text = "🗑 Limpar lista"
            setOnClickListener {
                store.limpar()
                montar()
                Toast.makeText(this@ListaActivity, "Lista limpa.", Toast.LENGTH_SHORT).show()
            }
        }
        container.addView(btnLimpar, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun itemLabel(item: ItemLista): String = item.mercado

    private fun linha(item: ItemLista, index: Int): LinearLayout {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }

        val img = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            setBackgroundColor(0xFF171D36.toInt())
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        carregarImagem(img, item.codigo, item.imagem)
        linha.addView(img)

        val texto = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(dp(12), 0, dp(8), 0)
        }
        texto.addView(TextView(this).apply {
            text = item.descricao
            setTextColor(Color.WHITE)
            textSize = 15f
            maxLines = 2
        })
        texto.addView(TextView(this).apply {
            text = "${item.mercado} · ${item.precoDisplay}" +
                (if (item.economiaValor > 0) "   (economia ${item.economiaDisplay})" else "")
            setTextColor(if (item.economiaValor > 0) 0xFF4ADE80.toInt() else 0xFF9AA4BF.toInt())
            textSize = 13f
        })
        linha.addView(texto)

        val btnExcluir = Button(this).apply {
            text = "✕"
            setOnClickListener {
                store.remover(index)
                montar()
            }
        }
        linha.addView(btnExcluir, ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))

        return linha
    }

    private fun divisor(): android.view.View {
        val v = android.view.View(this)
        v.setBackgroundColor(0xFF2E3A66.toInt())
        return v
    }

    private fun moeda(v: Double): String = String.format(Locale("pt", "BR"), "R$ %.2f", v)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
