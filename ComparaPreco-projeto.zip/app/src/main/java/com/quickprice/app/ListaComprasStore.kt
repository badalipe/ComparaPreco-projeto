package com.quickprice.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

internal data class ItemLista(
    val descricao: String,
    val codigo: String,
    val precoDisplay: String,
    val precoValor: Double,
    val mercado: String,
    val economiaDisplay: String,
    val economiaValor: Double,
    val imagem: String
)

/** Lista de compras salva no aparelho (fica mesmo fechando o app). */
internal class ListaComprasStore(context: Context) {
    private val prefs = context.getSharedPreferences("lista_compras", Context.MODE_PRIVATE)

    fun todos(): List<ItemLista> {
        val raw = prefs.getString("itens", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val lista = ArrayList<ItemLista>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            lista.add(ItemLista(
                descricao = o.optString("d"),
                codigo = o.optString("c"),
                precoDisplay = o.optString("p"),
                precoValor = o.optDouble("pv"),
                mercado = o.optString("m"),
                economiaDisplay = o.optString("e"),
                economiaValor = o.optDouble("ev"),
                imagem = o.optString("i")
            ))
        }
        return lista
    }

    fun adicionar(item: ItemLista) {
        val arr = JSONArray(prefs.getString("itens", "[]") ?: "[]")
        arr.put(JSONObject().apply {
            put("d", item.descricao); put("c", item.codigo)
            put("p", item.precoDisplay); put("pv", item.precoValor)
            put("m", item.mercado); put("e", item.economiaDisplay)
            put("ev", item.economiaValor); put("i", item.imagem)
        })
        prefs.edit().putString("itens", arr.toString()).apply()
    }

    fun remover(index: Int) {
        val arr = JSONArray(prefs.getString("itens", "[]") ?: "[]")
        val novo = JSONArray()
        for (i in 0 until arr.length()) if (i != index) novo.put(arr.get(i))
        prefs.edit().putString("itens", novo.toString()).apply()
    }

    fun limpar() = prefs.edit().remove("itens").apply()

    fun tamanho(): Int = todos().size

    fun economiaTotal(): Double = todos().sumOf { it.economiaValor }
}
