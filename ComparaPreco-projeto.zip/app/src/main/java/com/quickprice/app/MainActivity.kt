package com.quickprice.app

import android.content.Intent
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebSettings
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import java.math.BigDecimal
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val pool = Executors.newFixedThreadPool(3)
    private val keepAlive = Executors.newSingleThreadScheduledExecutor()
    private lateinit var store: MarketStore
    private lateinit var userAgent: String

    private lateinit var txtStatus: TextView
    private lateinit var txtProduto: TextView
    private lateinit var txtCodigo: TextView
    private lateinit var txtDiff: TextView
    private lateinit var cardA: LinearLayout
    private lateinit var cardB: LinearLayout
    private lateinit var nomeA: TextView
    private lateinit var nomeB: TextView
    private lateinit var precoA: TextView
    private lateinit var precoB: TextView
    private lateinit var seloA: TextView
    private lateinit var seloB: TextView
    private lateinit var logoA: ImageView
    private lateinit var logoB: ImageView
    private lateinit var imgProduto: ImageView
    private lateinit var imgBackdrop: ImageView
    private lateinit var edtCodigo: EditText
    private lateinit var btnScan: Button

    @Volatile private var clientA: CartazFacilClient? = null
    @Volatile private var clientB: CartazFacilClient? = null
    @Volatile private var busyLogin = false
    @Volatile private var imagemToken = 0
    private var soundPool: SoundPool? = null
    private var bipId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = MarketStore(this)
        userAgent = WebSettings.getDefaultUserAgent(applicationContext)
        soundPool = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build().also { bipId = it.load(this, R.raw.bip, 1) }

        txtStatus = findViewById(R.id.txtStatus)
        txtProduto = findViewById(R.id.txtProduto)
        txtCodigo = findViewById(R.id.txtCodigo)
        txtDiff = findViewById(R.id.txtDiff)
        cardA = findViewById(R.id.cardA)
        cardB = findViewById(R.id.cardB)
        nomeA = findViewById(R.id.nomeA)
        nomeB = findViewById(R.id.nomeB)
        precoA = findViewById(R.id.precoA)
        precoB = findViewById(R.id.precoB)
        seloA = findViewById(R.id.seloA)
        seloB = findViewById(R.id.seloB)
        logoA = findViewById(R.id.logoA)
        logoB = findViewById(R.id.logoB)
        imgProduto = findViewById(R.id.imgProduto)
        imgBackdrop = findViewById(R.id.imgBackdrop)
        edtCodigo = findViewById(R.id.edtCodigo)
        btnScan = findViewById(R.id.btnScan)

        btnScan.setOnClickListener { abrirScanner() }
        edtCodigo.setOnEditorActionListener { _, actionId, event ->
            val enter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE || enter) {
                consultar(edtCodigo.text.toString())
                true
            } else false
        }

        val ma = store.mercadoA()
        val mb = store.mercadoB()
        nomeA.text = ma.nome
        nomeB.text = mb.nome
        aplicarLogo(logoA, ma.baseUrl)
        aplicarLogo(logoB, mb.baseUrl)
        conectarTudo()
        iniciarKeepAlive()
    }

    private fun aplicarLogo(img: ImageView, baseUrl: String) {
        val res = when {
            baseUrl.contains("carlaosupermercados", ignoreCase = true) -> R.drawable.logo_supercarlao
            baseUrl.contains("rmarket", ignoreCase = true) -> R.drawable.logo_redemarket
            else -> null
        }
        if (res == null) img.visibility = View.GONE else {
            img.visibility = View.VISIBLE
            img.setImageResource(res)
        }
    }

    private fun conectarTudo() {
        if (busyLogin) return
        busyLogin = true
        btnScan.isEnabled = false
        val ma = store.mercadoA()
        val mb = store.mercadoB()
        txtStatus.text = "Conectando em ${ma.nome} e ${mb.nome}..."
        pool.execute {
            val a = runCatching { CartazFacilClient(userAgent, ma.baseUrl).also { it.login(ma.usuario, ma.senha) } }
            val b = runCatching { CartazFacilClient(userAgent, mb.baseUrl).also { it.login(mb.usuario, mb.senha) } }
            clientA = a.getOrNull()
            clientB = b.getOrNull()
            runOnUiThread {
                busyLogin = false
                btnScan.isEnabled = true
                txtStatus.text = when {
                    clientA != null && clientB != null -> "Conectado nos dois mercados. Escaneie um produto."
                    clientA != null -> "Só ${ma.nome} conectou. Verifique o login de ${mb.nome} em Ajustes."
                    clientB != null -> "Só ${mb.nome} conectou. Verifique o login de ${ma.nome} em Ajustes."
                    else -> "Nenhum mercado conectou. Toque em AJUSTES para conferir usuários e senhas."
                }
            }
        }
    }

    private fun consultar(codigo: String) {
        val limpo = codigo.trim()
        if (limpo.isEmpty()) return
        val ca = clientA
        val cb = clientB
        if (ca == null && cb == null) {
            Toast.makeText(this, "Nenhum mercado conectado.", Toast.LENGTH_SHORT).show()
            return
        }
        txtStatus.text = "Consultando \"$limpo\" nos dois mercados..."
        btnScan.isEnabled = false
        txtProduto.text = "Consultando..."
        precoA.text = "R$ -"
        precoB.text = "R$ -"
        imagemToken++
        mostrarImagem(null)

        val latch = CountDownLatch(2)
        var resA: Result<PriceLookupResult>? = null
        var resB: Result<PriceLookupResult>? = null
        pool.execute { resA = consultarSeguro(ca, store.mercadoA(), limpo); latch.countDown() }
        pool.execute { resB = consultarSeguro(cb, store.mercadoB(), limpo); latch.countDown() }
        latch.await(25, TimeUnit.SECONDS)

        runOnUiThread {
            btnScan.isEnabled = true
            mostrarResultado(limpo, resA, resB)
        }
    }

    /**
     * Consulta com reconexão: se a sessão caiu (outro funcionário logou em outro PC),
     * faz login de novo e repete a consulta automaticamente.
     */
    private fun consultarSeguro(client: CartazFacilClient?, cfg: MercadoConfig, codigo: String): Result<PriceLookupResult> {
        if (client == null) return Result.failure(RuntimeException("Mercado não conectado"))
        val r1 = runCatching { client.lookupPrice(codigo) }
        val err = r1.exceptionOrNull()
        val sessaoCaiu = err is CartazLoginException ||
            (err?.message?.contains("HTTP", ignoreCase = true) == true)
        if (!sessaoCaiu) return r1
        val relogin = runCatching { client.login(cfg.usuario, cfg.senha) }
        return if (relogin.isSuccess) runCatching { client.lookupPrice(codigo) } else r1
    }

    /** Mantém a sessão ativa: a cada poucos minutos refaz o login nos dois mercados,
     *  garantindo que o app "ganhe" a disputa do duplo login. */
    private fun iniciarKeepAlive() {
        keepAlive.scheduleWithFixedDelay({
            try {
                val ma = store.mercadoA()
                val mb = store.mercadoB()
                clientA?.let { runCatching { it.login(ma.usuario, ma.senha) } }
                clientB?.let { runCatching { it.login(mb.usuario, mb.senha) } }
            } catch (_: Exception) { }
        }, 2, 4, TimeUnit.MINUTES)
    }

    private fun mostrarResultado(codigo: String, resA: Result<PriceLookupResult>?, resB: Result<PriceLookupResult>?) {
        val ma = store.mercadoA()
        val mb = store.mercadoB()

        val okA = resA?.getOrNull()
        val okB = resB?.getOrNull()
        val precoValA = okA?.price?.amount
        val precoValB = okB?.price?.amount

        txtCodigo.text = "${okA?.product?.code ?: okB?.product?.code ?: "-"} · $codigo"
        txtProduto.text = okA?.product?.description
            ?: okB?.product?.description
            ?: "Produto não encontrado nos mercados."

        // Ordena: o MENOR preço sempre fica em cima.
        data class Item(val nome: String, val precoTxt: String, val valor: BigDecimal?)
        val itens = listOf(
            Item(ma.nome, okA?.let { "R$ ${it.price.display}" } ?: erroCurto(resA), precoValA),
            Item(mb.nome, okB?.let { "R$ ${it.price.display}" } ?: erroCurto(resB), precoValB)
        ).sortedWith(compareBy({ it.valor == null }, { it.valor ?: BigDecimal.ZERO }))

        val top = itens[0]
        val bottom = itens[1]
        val soUm = (precoValA != null) != (precoValB != null)

        nomeA.text = top.nome
        precoA.text = top.precoTxt
        nomeB.text = bottom.nome
        precoB.text = bottom.precoTxt

        // A logo acompanha o mercado (não o cartão)
        val urlTop = if (itens[0].nome == ma.nome) ma.baseUrl else mb.baseUrl
        val urlBottom = if (itens[1].nome == ma.nome) ma.baseUrl else mb.baseUrl
        aplicarLogo(logoA, urlTop)
        aplicarLogo(logoB, urlBottom)

        cardA.setBackgroundResource(R.drawable.bg_card_vencedor)
        seloA.visibility = if (top.valor != null) View.VISIBLE else View.INVISIBLE
        seloA.text = if (soUm) "ÚNICO PREÇO" else "★ MENOR PREÇO"

        cardB.setBackgroundResource(R.drawable.bg_card_normal)
        seloB.visibility = if (top.valor != null && bottom.valor != null) View.VISIBLE else View.INVISIBLE

        txtDiff.text = when {
            precoValA != null && precoValB != null -> {
                val dif = (precoValA - precoValB).abs()
                val venc = if (precoValA <= precoValB) ma.nome else mb.nome
                "Diferença de R$ ${fmt(dif)} — melhor preço: $venc"
            }
            precoValA != null -> "Só ${ma.nome} tem este produto."
            precoValB != null -> "Só ${mb.nome} tem este produto."
            else -> "Preço indisponível nos dois mercados."
        }

        if (okA != null || okB != null) {
            soundPool?.play(bipId, 1f, 1f, 1, 0, 1f)
            buscarImagemProduto(codigo)
        }
        txtStatus.text = "Conectado nos dois mercados. Escaneie um produto."
    }

    /** Foto do produto: consulta o BeepScan e pega a imagem (og:image ou primeira img). */
    private fun buscarImagemProduto(codigoBarras: String) {
        val token = ++imagemToken
        pool.execute {
            val imageUrl: String? = try {
                val document = org.jsoup.Jsoup.connect("https://www.beepscan.com/barcode/$codigoBarras")
                    .userAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                    .timeout(8000)
                    .get()
                document.selectFirst("meta[property=og:image]")?.attr("abs:content")
                    ?.takeIf { it.startsWith("http") }
                    ?: document.select("img[src]")
                        .map { it.attr("abs:src") }
                        .firstOrNull {
                            it.startsWith("http") &&
                                !it.endsWith(".svg", ignoreCase = true) &&
                                !it.contains("logo", ignoreCase = true)
                        }
            } catch (e: Exception) {
                Log.e("MainActivity", "Erro ao buscar imagem: ${e.message}")
                null
            }
            runOnUiThread { if (token == imagemToken) mostrarImagem(imageUrl) }
        }
    }

    /** Foto com degradê estilo Netflix + fundo desfocado atrás. */
    private fun mostrarImagem(model: String?) {
        if (isFinishing || isDestroyed) return
        if (model.isNullOrEmpty()) {
            Glide.with(this).clear(imgBackdrop)
            imgBackdrop.setImageDrawable(null)
            imgProduto.setImageResource(R.drawable.ic_placeholder_box)
            return
        }
        Glide.with(this)
            .load(model)
            .error(R.drawable.ic_placeholder_box)
            .transform(NetflixEdgeTransformation.getTransformation())
            .into(imgProduto)

        Glide.with(this)
            .load(model)
            .override(24, 48)
            .transform(CenterCrop())
            .into(imgBackdrop)
    }

    private fun erroCurto(r: Result<PriceLookupResult>?): String = when {
        r == null -> "Mercado não conectado"
        r.getOrNull() != null -> "R$ ${r.getOrNull()!!.price.display}"
        r.exceptionOrNull() is ProductNotFoundException -> "Não encontrado"
        r.exceptionOrNull() is AmbiguousProductException -> "Mais de um produto"
        r.exceptionOrNull() is CartazLoginException -> "Sessão expirou"
        else -> {
            val msg = r.exceptionOrNull()?.message ?: "sem detalhes"
            "Erro: " + msg.take(70)
        }
    }

    private fun fmt(v: BigDecimal): String {
        val parts = v.toPlainString().split(".")
        val inteiros = parts[0].reversed().chunked(3).joinToString(".").reversed()
        val dec = (parts.getOrNull(1) ?: "0").padEnd(2, '0').take(2)
        return "$inteiros,$dec"
    }

    private fun abrirScanner() {
        startActivityForResult(Intent(this, ScannerActivity::class.java), REQ_SCAN)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SCAN && resultCode == RESULT_OK) {
            val codigo = data?.getStringExtra("codigo").orEmpty()
            edtCodigo.setText(codigo)
            if (codigo.isNotEmpty()) consultar(codigo)
        }
    }

    override fun onDestroy() {
        soundPool?.release()
        soundPool = null
        pool.shutdownNow()
        keepAlive.shutdownNow()
        super.onDestroy()
    }

    companion object { private const val REQ_SCAN = 42 }
}
